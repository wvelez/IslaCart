MoneyScripts MS Core for Drupal
Author: Leighton Whiting
Copyright 2008-2013 MoneyScripts.net - Leighton Whiting

Requirements:
-------------
-Drupal 7
-Token (http://drupal.org/project/token)

Installation:
-------------
Install the module just like you would any other Drupal Module
Video Tutorial: https://www.moneyscripts.net/module-faqs/do-i-need-webmaster-install-me-my-site

Helpful Links:
--------------

Tutorials:
https://www.moneyscripts.net/tutorials

Support Forums:
http://www.moneyscripts.net/forums
