MoneyScripts Realex Payment Gateway
Author: Leighton Whiting
Copyright 2008-2013 MoneyScripts.net - Leighton Whiting

MS Realex provides integration for the Remote, Redirect, and RealVault payment
methods via Realex. Recurring payments are supported through RealVault and
a cron job on your site. The recurring payments are charged during cron when
they should be. The payment information is stored on Realex's secure servers
so PCI Compliance is easy.

For the Remote method, you will need an SSL Certificate.